# EdgeTools dependency package marker.
