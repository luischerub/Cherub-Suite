
import bpy
from .operators import classes
from .ui import register_ui, unregister_ui
from .asset_settings import register_properties, unregister_properties
from .operators.add_hotkey import add_hotkey, remove_hotkey, draw_keymap_items
from bpy.types import AddonPreferences as Preferences
from bpy.props import (
    FloatProperty,
    EnumProperty,
)

class CHERUBPIES_MT_Prefs(Preferences):
    bl_idname = __package__

    prefs_tabs: EnumProperty(
        items=(
            ("options", "Options", "ADDON OPTIONS"),
            ("keymaps", "Keymaps", "CHANGE KEYMAPS"),
        ),
        default="keymaps",
    )

    scale_y: FloatProperty(name="", default=1, min=1, max=2)
    # reinstall: BoolProperty(
    #     name="Reinstall",
    #     description="Force reinstalling curernt version",
    #     default=False,
    # )

    def draw(self, context):
        layout = self.layout

        row = layout.row(align=True)
        row.prop(self, "prefs_tabs", expand=True)

        if self.prefs_tabs == "options":
            box = layout.box()
            row = box.row(align=True)
            row.label(text="Pie Menus Buttons Scale Y :")
            row.prop(self, "scale_y", expand=True, text=" ")

            userpref = context.preferences
            view = userpref.view
            row = box.row(align=True)
            row.label(text="Pie Menus Radius :")
            row.prop(view, "pie_menu_radius", expand=True, text=" ")

        if self.prefs_tabs == "keymaps":
            wm = bpy.context.window_manager
            draw_keymap_items(wm, layout)


classes.append(CHERUBPIES_MT_Prefs)


def register():
    register_ui()
    register_properties()

    for c in classes:
        bpy.utils.register_class(c)

    if hasattr(bpy.types, "BezierDeformProperties") and not hasattr(bpy.types.Scene, "bezierDeformProperties"):
        bpy.types.Scene.bezierDeformProperties = bpy.props.PointerProperty(type=bpy.types.BezierDeformProperties)

    add_hotkey()

    addon_name = "Cherub Suite"
    print("Registered {}".format(addon_name))


def unregister():
    if hasattr(bpy.types.Scene, "bezierDeformProperties"):
        del bpy.types.Scene.bezierDeformProperties

    unregister_properties()
    unregister_ui()

    for c in classes:
        bpy.utils.unregister_class(c)

    remove_hotkey()

    addon_name = "Cherub Suite"
    print("Unregistered {}".format(addon_name))

